该项目用于读取冻结后的pb文件并进行预测  
使用步骤：   
（1）准备好需要使用的pb冻结文件，pbtxt标签文件，测试用的图片  
（2）修改info.config文件中的相关信息  

![Example image](https://tensorflowob/raw/master/object_detection/readPbFile/example1.jpg)     
![Example image](https://tensorflowob/raw/master/object_detection/readPbFile/example2.jpg)